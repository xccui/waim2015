
Springer Office 2007 - Word Style Sheet
=======================================

This archive contains the Office 2007 Word style sheet for the series
Lecture Notes in Computer Science.

The current version is named "sv-ln20090127.dotm".
If you double-click on it,  you have to allow the Word macro processing
for the current document to be able to use the builtin features.

The document "typeinst.doc" contains general and typing instructions;
it may be used as a template.
